#FlexiTimer2 Library#

Run a function on a configurable interval.

http://playground.arduino.cc/Main/FlexiTimer2

https://github.com/wimleers/flexitimer2

http://www.pjrc.com/teensy/td_libs_MsTimer2.html

Based on MsTimer2 originally written by Javier Valencia.

Wim Leers added code which makes interval resolution configurable,
